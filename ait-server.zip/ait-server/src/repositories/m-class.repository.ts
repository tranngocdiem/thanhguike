import {DefaultCrudRepository, juggler} from '@loopback/repository';
import {MClass} from '../models';
import {inject} from '@loopback/core';

export class MClassRepository extends DefaultCrudRepository<
  MClass,
  typeof MClass.prototype.precode
> {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(MClass, datasource);
  }
}
