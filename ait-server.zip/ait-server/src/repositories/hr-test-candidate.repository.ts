import { DefaultCrudRepository, juggler } from '@loopback/repository';
import { HrTestCandidate } from '../models';
import { inject } from '@loopback/core';

export class HrTestCandidateRepository extends DefaultCrudRepository<
  HrTestCandidate,
  typeof HrTestCandidate.prototype.candidateCode
  > {
  constructor(
    @inject('datasources.ait') protected datasource: juggler.DataSource,
  ) {
    super(HrTestCandidate, datasource);
  }
}
