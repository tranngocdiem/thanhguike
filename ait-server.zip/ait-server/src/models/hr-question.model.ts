import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_question' })
export class HrQuestion extends Entity {
  @property({
    type: 'number',
    id: true,

  })
  id: number;

  @property({
    type: 'string',

  })
  category: string;

  @property({
    type: 'string',

  })
  level: string;

  @property({
    type: 'string',
    required: true,
  })
  content: string;

  @property({
    type: 'string',
  })
  image?: string;

  @property({
    type: 'boolean',
  })
  activeflag?: boolean;

  constructor(data?: Partial<HrQuestion>) {
    super(data);
  }
}
