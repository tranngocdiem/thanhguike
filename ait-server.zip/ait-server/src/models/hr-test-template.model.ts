import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_test_template' })
export class HrTestTemplate extends Entity {

  @property({
    type: 'string',
    id: true,
    required: true,

  })
  code: string;

  @property({
    type: 'string',
    required: true,

  })
  name: string;

  @property({
    type: 'number',

  })
  time?: number;

  @property({
    type: 'boolean',
    default: false,

  })
  activeFlag?: boolean;

  constructor(data?: Partial<HrTestTemplate>) {
    super(data);
  }
}
