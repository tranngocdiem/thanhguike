import { Entity, model, property } from '@loopback/repository';

@model({ name: 'hr_test_candidate_question' })
export class HrTestCandidateQuestion extends Entity {
  @property({
    type: 'string',
    id: true,
    required: true,
  })
  candidateCode: string;

  @property({
    type: 'string',
    required: true,
  })
  category: string;

  @property({
    type: 'number',
    required: true,
  })
  no: number;

  @property({
    type: 'number',
    required: true,
  })
  questionId: number;

  @property({
    type: 'string',
  })
  content?: string;

  @property({
    type: 'string',
  })
  image?: string;

  constructor(data?: Partial<HrTestCandidateQuestion>) {
    super(data);
  }
}
