import { Filter, Where, repository } from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import { HrTestCandidate } from '../models';
import { HrTestCandidateRepository } from '../repositories';

export class HrTestCandidateController {
  constructor(
    @repository(HrTestCandidateRepository)
    public hrTestCandidateRepository: HrTestCandidateRepository,
  ) { }

  @post('/hr-test-candidates')
  async create(@requestBody() obj: HrTestCandidate)
    : Promise<HrTestCandidate> {
    return await this.hrTestCandidateRepository.create(obj);
  }

  @get('/hr-test-candidates/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestCandidateRepository.count(where);
  }

  @get('/hr-test-candidates')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrTestCandidate[]> {
    return await this.hrTestCandidateRepository.find(filter);
  }

  @patch('/hr-test-candidates')
  async updateAll(
    @requestBody() obj: HrTestCandidate,
    @param.query.string('where') where?: Where
  ): Promise<number> {
    return await this.hrTestCandidateRepository.updateAll(obj, where);
  }

  @get('/hr-test-candidates/{id}')
  async findById(@param.path.number('id') id: string): Promise<HrTestCandidate> {
    return await this.hrTestCandidateRepository.findById(id);
  }

  @patch('/hr-test-candidates/{id}')
  async updateById(
    @param.path.number('id') id: string,
    @requestBody() obj: HrTestCandidate
  ): Promise<boolean> {
    return await this.hrTestCandidateRepository.updateById(id, obj);
  }

  @del('/hr-test-candidates/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrTestCandidateRepository.deleteById(id);
  }
}
