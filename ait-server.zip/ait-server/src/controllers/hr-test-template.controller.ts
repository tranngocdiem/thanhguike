import {Filter, Where, repository} from '@loopback/repository';
import {post, param, get, patch, del, requestBody} from '@loopback/rest';
import {HrTestTemplate} from '../models';
import {HrTestTemplateRepository} from '../repositories';

export class HrTestTemplateController {
  constructor(
    @repository(HrTestTemplateRepository)
    public hrTestTemplateRepository: HrTestTemplateRepository,
  ) {}

  @post('/hr-test-templates')
  async create(@requestBody() obj: HrTestTemplate): Promise<HrTestTemplate> {
    return await this.hrTestTemplateRepository.create(obj);
  }

  @get('/hr-test-templates/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestTemplateRepository.count(where);
  }

  @get('/hr-test-templates')
  async find(
    @param.query.string('filter') filter?: Filter,
  ): Promise<HrTestTemplate[]> {
    return await this.hrTestTemplateRepository.find(filter);
  }

  @patch('/hr-test-templates')
  async updateAll(
    @requestBody() obj: HrTestTemplate,
    @param.query.string('where') where?: Where,
  ): Promise<number> {
    return await this.hrTestTemplateRepository.updateAll(obj, where);
  }

  @del('/hr-test-templates')
  async deleteAll(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrTestTemplateRepository.deleteAll(where);
  }

  @get('/hr-test-templates/{id}')
  async findById(@param.path.string('id') id: string): Promise<HrTestTemplate> {
    return await this.hrTestTemplateRepository.findById(id);
  }

  @patch('/hr-test-templates/{id}')
  async updateById(
    @param.path.string('id') id: string,
    @requestBody() obj: HrTestTemplate,
  ): Promise<boolean> {
    return await this.hrTestTemplateRepository.updateById(id, obj);
  }

  @del('/hr-test-templates/{id}')
  async deleteById(@param.path.string('id') id: string): Promise<boolean> {
    return await this.hrTestTemplateRepository.deleteById(id);
  }
}
