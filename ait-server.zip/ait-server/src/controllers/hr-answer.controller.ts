import { Filter, Where, repository } from '@loopback/repository';
import {
  post,
  param,
  get,
  patch,
  del,
  requestBody
} from '@loopback/rest';
import { HrAnswer } from '../models';
import { HrAnswerRepository } from '../repositories';

export class HrAnswerController {
  constructor(
    @repository(HrAnswerRepository)
    public hrAnswerRepository: HrAnswerRepository,
  ) { }

  @post('/hr-answers')
  async create(@requestBody() obj: HrAnswer)
    : Promise<HrAnswer> {
    return await this.hrAnswerRepository.create(obj);
  }
  @post('/hr-answers/all')
  async createAll(
    @requestBody() entities: Partial<HrAnswer>[])
    : Promise<HrAnswer[]> {
    return await this.hrAnswerRepository.createAll(entities);
  }

  @get('/hr-answers/count')
  async count(@param.query.string('where') where?: Where): Promise<number> {
    return await this.hrAnswerRepository.count(where);
  }

  @get('/hr-answers')
  async find(@param.query.string('filter') filter?: Filter)
    : Promise<HrAnswer[]> {
    return await this.hrAnswerRepository.find(filter);
  }

  @patch('/hr-answers')
  async updateAll(
    @requestBody() obj: HrAnswer,
    @param.query.string('where') where?: Where
  ): Promise<number> {
    return await this.hrAnswerRepository.updateAll(obj, where);
  }

  @get('/hr-answers/{id}')
  async findById(@param.path.string('id') id: number): Promise<HrAnswer> {
    return await this.hrAnswerRepository.findById(id);
  }

  @patch('/hr-answers/{id}')
  async updateById(
    @param.path.string('id') id: number,
    @requestBody() obj: HrAnswer
  ): Promise<boolean> {
    return await this.hrAnswerRepository.updateById(id, obj);
  }

  @del('/hr-answers/{id}')
  async deleteById(@param.path.string('id') id: number): Promise<boolean> {
    return await this.hrAnswerRepository.deleteById(id);
  }

  @patch('/hr-answers-update')
  async updateAllData(
    @requestBody() obj: HrAnswer[]
  ): Promise<HrAnswer[]> {
    await this.hrAnswerRepository.deleteAll({ questionid: obj[0].questionid })
    return await this.hrAnswerRepository.createAll(obj);
  }

}
